export default function Header() {
  return (
    <header className="relative overflow-hidden border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-xl">
      {/* Animated gradient orbs */}
      <div className="absolute -top-24 -left-24 h-48 w-48 rounded-full bg-brand-500/20 blur-3xl animate-pulse" />
      <div className="absolute -top-24 -right-24 h-48 w-48 rounded-full bg-purple-500/20 blur-3xl animate-pulse delay-1000" />

      <div className="relative mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Badge */}
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-brand-500/30 bg-brand-500/10 px-4 py-1.5">
            <span className="h-2 w-2 rounded-full bg-brand-400 animate-pulse" />
            <span className="text-xs font-medium text-brand-300 tracking-wide uppercase">
              Operating Systems
            </span>
          </div>

          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl lg:text-5xl">
            <span className="bg-gradient-to-r from-white via-brand-200 to-brand-400 bg-clip-text text-transparent">
              Disk Scheduling
            </span>{" "}
            <span className="text-slate-300">Simulator</span>
          </h1>

          <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-400 sm:text-base">
            Visualize &amp; compare <strong className="text-brand-300">FCFS</strong>,{" "}
            <strong className="text-brand-300">SSTF</strong>,{" "}
            <strong className="text-brand-300">SCAN</strong>, and{" "}
            <strong className="text-brand-300">C-SCAN</strong> algorithms with interactive graphs
            and real-time performance metrics.
          </p>
        </div>
      </div>
    </header>
  );
}
