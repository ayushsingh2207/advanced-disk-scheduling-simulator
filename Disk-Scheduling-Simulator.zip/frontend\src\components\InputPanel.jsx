import { useState } from "react";

const ALGORITHMS = [
  { id: "fcfs", label: "FCFS", desc: "First Come First Served" },
  { id: "sstf", label: "SSTF", desc: "Shortest Seek Time First" },
  { id: "scan", label: "SCAN", desc: "Elevator Algorithm" },
  { id: "cscan", label: "C-SCAN", desc: "Circular SCAN" },
];

export default function InputPanel({ onSimulate, onCompare, loading }) {
  const [requests, setRequests] = useState("98, 183, 37, 122, 14, 124, 65, 67");
  const [head, setHead] = useState("53");
  const [maxTrack, setMaxTrack] = useState("199");
  const [algorithm, setAlgorithm] = useState("fcfs");
  const [direction, setDirection] = useState("right");

  const parseInputs = () => {
    const reqArr = requests
      .split(",")
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n));
    return {
      requests: reqArr,
      head: parseInt(head, 10),
      maxTrack: parseInt(maxTrack, 10),
      algorithm,
      direction,
    };
  };

  const handleSimulate = () => onSimulate(parseInputs());
  const handleCompare = () => onCompare(parseInputs());

  return (
    <div className="glass-card-solid p-8 animate-slide-up relative overflow-visible">
      {/* Decorative glow behind header */}
      <div className="absolute top-[-50px] left-[-50px] w-64 h-64 bg-brand-500/20 rounded-full blur-[80px] pointer-events-none"></div>
      
      <h2 className="mb-8 text-2xl font-display font-black tracking-tight text-white flex items-center gap-4 relative z-10">
        <div className="relative flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-400 to-brand-600 text-white shadow-[0_0_25px_rgba(139,92,246,0.5)]">
          <span className="relative z-10 text-xl">⚙</span>
          <div className="absolute inset-0 rounded-2xl border border-white/20"></div>
        </div>
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 drop-shadow-sm">
          Configuration
        </span>
      </h2>

      {/* Disk Requests */}
      <div className="mb-7 relative group">
        <label className="mb-2 block text-[11px] font-extrabold uppercase tracking-[0.2em] text-brand-400 transition-colors group-hover:text-brand-300">
          Disk Access Requests
        </label>
        <div className="relative">
          <textarea
            id="disk-requests-input"
            rows={2}
            className="input-field resize-none relative z-10"
            placeholder="e.g. 98, 183, 37, 122, 14, 124, 65, 67"
            value={requests}
            onChange={(e) => setRequests(e.target.value)}
          />
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-brand-500/0 via-brand-500/0 to-brand-500/0 transition-all duration-500 group-hover:from-brand-500/10 group-hover:via-pink-500/5 group-hover:to-brand-500/10 blur-xl z-0"></div>
        </div>
        <p className="mt-2 text-[11px] font-semibold tracking-wider text-slate-500">Comma-separated track numbers</p>
      </div>

      {/* Head + Max Track */}
      <div className="mb-7 grid grid-cols-2 gap-6">
        <div className="relative group">
          <label className="mb-2 block text-[11px] font-extrabold uppercase tracking-[0.2em] text-brand-400 transition-colors group-hover:text-brand-300">
            Head Position
          </label>
          <input
            id="head-position-input"
            type="number"
            className="input-field"
            placeholder="53"
            value={head}
            onChange={(e) => setHead(e.target.value)}
          />
        </div>
        <div className="relative group">
          <label className="mb-2 block text-[11px] font-extrabold uppercase tracking-[0.2em] text-brand-400 transition-colors group-hover:text-brand-300">
            Max Track
          </label>
          <input
            id="max-track-input"
            type="number"
            className="input-field"
            placeholder="199"
            value={maxTrack}
            onChange={(e) => setMaxTrack(e.target.value)}
          />
        </div>
      </div>

      {/* Algorithm Selector */}
      <div className="mb-8 relative z-10">
        <label className="mb-3 block text-[11px] font-extrabold uppercase tracking-[0.2em] text-brand-400">
          Algorithm
        </label>
        <div className="grid grid-cols-2 gap-3">
          {ALGORITHMS.map((algo) => (
            <button
              key={algo.id}
              id={`algo-btn-${algo.id}`}
              onClick={() => setAlgorithm(algo.id)}
              className={`group relative rounded-2xl border p-4 text-left transition-all duration-500 ease-spring overflow-hidden ${
                algorithm === algo.id
                  ? "border-brand-400/50 bg-brand-500/10 shadow-[0_0_25px_rgba(139,92,246,0.4)] scale-[1.02]"
                  : "border-white/5 bg-white/5 hover:border-white/20 hover:bg-white/10 hover:shadow-[0_0_15px_rgba(255,255,255,0.05)] hover:-translate-y-1"
              }`}
            >
              {/* Highlight sweep effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>

              <span
                className={`block text-lg font-display font-black tracking-tight transition-all duration-500 ${
                  algorithm === algo.id ? "text-transparent bg-clip-text bg-gradient-to-r from-brand-300 to-pink-400" : "text-white group-hover:text-brand-200"
                }`}
              >
                {algo.label}
              </span>
              <span className={`block mt-1 text-[10px] uppercase font-bold tracking-widest transition-colors duration-500 ${
                algorithm === algo.id ? "text-brand-300/90" : "text-slate-500 group-hover:text-slate-400"
              }`}>{algo.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Direction (only for SCAN) */}
      {algorithm === "scan" && (
        <div className="mb-8 animate-fade-in">
          <label className="mb-3 block text-[11px] font-extrabold uppercase tracking-[0.2em] text-brand-400">
            Initial Direction
          </label>
          <div className="flex gap-4">
            {["left", "right"].map((dir) => (
              <button
                key={dir}
                id={`direction-btn-${dir}`}
                onClick={() => setDirection(dir)}
                className={`flex-1 rounded-2xl border py-3 text-sm font-black uppercase tracking-wider transition-all duration-500 ease-spring ${
                  direction === dir
                    ? "border-brand-500/50 bg-brand-500/10 text-brand-300 shadow-[0_0_20px_rgba(139,92,246,0.3)] scale-[1.02]"
                    : "border-white/5 bg-white/5 text-slate-400 hover:border-white/20 hover:bg-white/10 hover:text-white hover:-translate-y-1"
                }`}
              >
                {dir === "left" ? "← Left" : "Right →"}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="mt-6 flex flex-col gap-3">
        <button
          id="simulate-btn"
          className="btn-primary w-full"
          onClick={handleSimulate}
          disabled={loading}
        >
          {loading ? (
            <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
          ) : (
            "▶"
          )}
          {loading ? "Simulating..." : "Simulate"}
        </button>
        <button
          id="compare-btn"
          className="btn-secondary w-full"
          onClick={handleCompare}
          disabled={loading}
        >
          ⚡ Compare All Algorithms
        </button>
      </div>
    </div>
  );
}
