/**
 * MetricsCard — Displays a single performance metric with an icon and value.
 */
export default function MetricsCard({ icon, label, value, unit, color = "brand" }) {
  const colorMap = {
    brand:   "from-brand-500/20 to-brand-600/5 border-brand-500/30 text-brand-400 group-hover:border-brand-400/50 group-hover:shadow-[0_0_30px_rgba(99,102,241,0.3)]",
    emerald: "from-emerald-500/20 to-emerald-600/5 border-emerald-500/30 text-emerald-400 group-hover:border-emerald-400/50 group-hover:shadow-[0_0_30px_rgba(16,185,129,0.3)]",
    amber:   "from-amber-500/20 to-amber-600/5 border-amber-500/30 text-amber-400 group-hover:border-amber-400/50 group-hover:shadow-[0_0_30px_rgba(245,158,11,0.3)]",
    rose:    "from-rose-500/20 to-rose-600/5 border-rose-500/30 text-rose-400 group-hover:border-rose-400/50 group-hover:shadow-[0_0_30px_rgba(244,63,94,0.3)]",
  };

  return (
    <div className="group relative w-full h-full perspective-1000">
      <div
        className={`
          relative flex flex-col items-center justify-center rounded-3xl border
          backdrop-blur-2xl p-5 text-center transition-all duration-500
          group-hover:-translate-y-2 group-hover:shadow-[0_0_40px_rgba(255,255,255,0.1)]
          bg-[#0a0a0a]/80 z-10 h-full w-full overflow-hidden
          ${colorMap[color] || colorMap.brand}
        `}
      >
        {/* Glow overlay inside the card */}
        <div className={`absolute inset-0 bg-gradient-to-br opacity-20 pointer-events-none z-[-1] transition-opacity duration-500 group-hover:opacity-50 ${colorMap[color]}`}></div>
        
        {/* Top highlight for 3D edge */}
        <div className="absolute top-0 left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-white/50 to-transparent opacity-60"></div>
        
        {/* Icon */}
        <span className="mb-2 text-3xl drop-shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-transform duration-500 group-hover:scale-125 group-hover:-translate-y-1">{icon}</span>
        
        {/* Value and Unit */}
        <div className="flex flex-col items-center gap-0 w-full px-1 overflow-visible">
          <span className="text-2xl sm:text-xl md:text-2xl lg:text-3xl font-display font-black text-white tracking-normal drop-shadow-md transition-all duration-500 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-b group-hover:from-white group-hover:to-slate-300 w-full overflow-visible">
            {value}
          </span>
          {unit && <span className="text-[10px] mt-1 font-extrabold text-slate-400/90 uppercase tracking-[0.2em]">{unit}</span>}
        </div>
        
        {/* Label */}
        <span className="mt-3 text-[11px] font-bold uppercase tracking-widest text-slate-500 transition-colors duration-300 group-hover:text-slate-300">
          {label}
        </span>
      </div>
    </div>
  );
}
