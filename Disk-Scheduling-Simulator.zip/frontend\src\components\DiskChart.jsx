import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";

// Neon Cyberpunk Palette
const COLORS = ["#06b6d4", "#d946ef", "#10b981", "#f59e0b", "#6366f1"];

/**
 * Custom tooltip for the chart — shows step, track, and seek time.
 */
function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-2xl border border-white/10 bg-[#0a0a0a]/90 px-5 py-4 shadow-[0_0_30px_rgba(6,182,212,0.2)] backdrop-blur-3xl">
      <p className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.2em] text-slate-500">Step {label}</p>
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center gap-3 my-1">
          <span className="w-2 h-2 rounded-full shadow-[0_0_10px_currentColor]" style={{ backgroundColor: entry.color, color: entry.color }}></span>
          <p className="text-base font-display font-bold text-white tracking-wide">
            {entry.name}: <span style={{ color: entry.color }}>Track {entry.value}</span>
          </p>
        </div>
      ))}
    </div>
  );
}

/**
 * DiskChart — visualizes the disk head movement sequence as a line chart.
 */
export default function DiskChart({ results, isComparison }) {
  if (!results) return null;

  // Build chart data
  let chartData = [];
  let lines = [];

  if (isComparison) {
    // For comparison: multiple lines on same chart
    const algNames = Object.keys(results);
    const maxLen = Math.max(...algNames.map((a) => results[a].sequence.length));

    for (let i = 0; i < maxLen; i++) {
      const point = { step: i };
      algNames.forEach((alg) => {
        point[alg] = results[alg].sequence[i] ?? null;
      });
      chartData.push(point);
    }

    lines = algNames.map((alg, idx) => ({
      key: alg,
      color: COLORS[idx % COLORS.length],
    }));
  } else {
    // Single algorithm
    chartData = results.sequence.map((track, i) => ({
      step: i,
      Track: track,
    }));
    lines = [{ key: "Track", color: COLORS[0] }];
  }

  return (
    <div className="glass-card-solid p-8 animate-slide-up relative overflow-hidden">
      {/* Decorative background glow for the chart container */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-cyan-500/5 blur-[100px] pointer-events-none z-0"></div>
      
      <h2 className="mb-8 text-xl font-display font-black tracking-tight text-white flex items-center gap-3 relative z-10">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 to-emerald-500/20 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
          📈
        </span>
        Disk Head Movement
      </h2>

      <div className="h-[400px] w-full relative z-10">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 20, right: 30, left: 10, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis
              dataKey="step"
              label={{ value: "STEP", position: "insideBottom", offset: -15, fill: "#475569", fontSize: 10, fontWeight: 800, letterSpacing: "0.2em" }}
              tick={{ fill: "#64748b", fontSize: 12, fontWeight: 600 }}
              stroke="rgba(255,255,255,0.1)"
              tickMargin={10}
            />
            <YAxis
              label={{
                value: "TRACK NUMBER",
                angle: -90,
                position: "insideLeft",
                offset: 20,
                fill: "#475569",
                fontSize: 10,
                fontWeight: 800,
                letterSpacing: "0.2em"
              }}
              tick={{ fill: "#64748b", fontSize: 12, fontWeight: 600 }}
              stroke="rgba(255,255,255,0.1)"
              tickMargin={10}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(255,255,255,0.1)', strokeWidth: 2, strokeDasharray: '4 4' }} />
            <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" />

            {lines.map((line) => (
              <Line
                key={line.key}
                type="monotone"
                dataKey={line.key}
                stroke={line.color}
                strokeWidth={4}
                dot={{ r: 5, fill: '#050505', stroke: line.color, strokeWidth: 3 }}
                activeDot={{ r: 8, fill: line.color, strokeWidth: 0, shadow: `0 0 15px ${line.color}` }}
                animationDuration={1500}
                animationEasing="ease-in-out"
                connectNulls
                style={{ filter: `drop-shadow(0 0 8px ${line.color}80)` }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Legend for comparison */}
      {isComparison && (
        <div className="mt-6 flex flex-wrap justify-center gap-6 relative z-10">
          {lines.map((line) => (
            <div key={line.key} className="flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 transition-all hover:bg-white/10 hover:border-white/20 cursor-default">
              <span
                className="h-3 w-3 rounded-full shadow-[0_0_10px_currentColor]"
                style={{ backgroundColor: line.color, color: line.color }}
              />
              <span className="text-xs font-bold tracking-widest uppercase text-white">{line.key}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
