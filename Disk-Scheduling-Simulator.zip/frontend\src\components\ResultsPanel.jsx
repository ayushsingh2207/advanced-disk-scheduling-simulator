import MetricsCard from "./MetricsCard";
import DiskChart from "./DiskChart";

/**
 * ResultsPanel — shows chart + metrics for single simulation or comparison.
 *
 * Props:
 *  - data: API response from /simulate or /compare
 *  - mode: "single" | "compare"
 */
export default function ResultsPanel({ data, mode }) {
  if (!data) return null;

  /* ─── Single Algorithm ─────────────────────────────── */
  if (mode === "single") {
    return (
      <div className="space-y-6 animate-fade-in">
        {/* Algorithm badge */}
        <div className="flex items-center gap-3">
          <span className="rounded-lg bg-brand-500/20 px-3 py-1 text-sm font-bold text-brand-300 border border-brand-500/30 shadow-[0_0_15px_rgba(139,92,246,0.2)]">
            {data.algorithm}
          </span>
          <span className="text-sm text-slate-400">
            Head starts at track <strong className="text-white">{data.head}</strong>
          </span>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <MetricsCard
            icon="🔄"
            label="Total Seek"
            value={data.totalSeekTime}
            unit="tracks"
            color="brand"
          />
          <MetricsCard
            icon="📏"
            label="Avg Seek"
            value={data.avgSeekTime}
            unit="tracks"
            color="emerald"
          />
          <MetricsCard
            icon="📈"
            label="Max Seek"
            value={data.maxSeekTime}
            unit="tracks"
            color="amber"
          />
          <MetricsCard
            icon="📉"
            label="Variance"
            value={data.variance}
            unit="tracks²"
            color="rose"
          />
          <MetricsCard
            icon="📊"
            label="Std Dev"
            value={data.standardDeviation}
            unit="tracks"
            color="brand"
          />
          <MetricsCard
            icon="⚡"
            label="Throughput"
            value={data.throughput}
            unit="req/tr"
            color="emerald"
          />
        </div>

        {/* Chart */}
        <DiskChart results={data} isComparison={false} />

        {/* Seek Sequence */}
        <div className="glass-card-solid p-6">
          <h3 className="mb-3 text-sm font-bold text-white flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-md bg-brand-500/20 text-brand-400 text-xs">
              →
            </span>
            Seek Sequence
          </h3>
          <div className="flex flex-wrap gap-2">
            {data.sequence.map((track, i) => (
              <span
                key={i}
                className={`inline-flex items-center rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  i === 0
                    ? "bg-brand-500/20 text-brand-300 border border-brand-500/30"
                    : "bg-slate-700/50 text-slate-300 border border-slate-600/30"
                }`}
              >
                {track}
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  /* ─── Comparison Mode ──────────────────────────────── */
  const algNames = Object.keys(data.results);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <span className="rounded-lg bg-brand-500/20 px-3 py-1 text-sm font-bold text-brand-300 border border-brand-500/30 shadow-[0_0_15px_rgba(139,92,246,0.2)]">
          COMPARISON
        </span>
        <span className="text-sm text-slate-400">
          All algorithms · Head at <strong className="text-white">{data.head}</strong>
        </span>
      </div>

      {/* Chart with all algorithms */}
      <DiskChart results={data.results} isComparison={true} />

      {/* Comparison Table */}
      <div className="glass-card-solid overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/50 bg-[#0f172a]/80 backdrop-blur-md">
                <th className="px-6 py-4 text-left text-xs font-bold uppercase tracking-wider text-slate-400">
                  Algorithm
                </th>
                <th className="px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400">
                  Total
                </th>
                <th className="px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400">
                  Avg
                </th>
                <th className="px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400">
                  Max
                </th>
                <th className="px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400">
                  Variance
                </th>
                <th className="px-6 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-400">
                  Throughput
                </th>
              </tr>
            </thead>
            <tbody>
              {algNames.map((alg, i) => {
                const r = data.results[alg];
                // Highlight the best (lowest total seek time)
                const bestSeek = Math.min(...algNames.map((a) => data.results[a].totalSeekTime));
                const isBest = r.totalSeekTime === bestSeek;
                return (
                  <tr
                    key={alg}
                    className={`group border-b border-white/5 transition-all duration-500 ease-spring hover:bg-white/10 hover:shadow-[0_0_20px_rgba(255,255,255,0.05)] hover:scale-[1.01] hover:z-10 relative ${
                      isBest ? "bg-brand-500/10" : ""
                    }`}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className="font-display font-bold text-white tracking-wide group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-brand-300 group-hover:to-pink-400 transition-all duration-500">{alg}</span>
                        {isBest && (
                          <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] uppercase font-bold tracking-widest text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)] border border-amber-500/30">
                            Best
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-bold text-slate-200">
                      {r.totalSeekTime}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-slate-300">
                      {r.avgSeekTime}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-slate-300">
                      {r.maxSeekTime}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-slate-300">
                      {r.variance}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-slate-300">
                      {r.throughput}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
