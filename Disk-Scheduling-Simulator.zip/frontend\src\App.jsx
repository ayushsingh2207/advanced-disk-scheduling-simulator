import { useState } from "react";
import Header from "./components/Header";
import InputPanel from "./components/InputPanel";
import ResultsPanel from "./components/ResultsPanel";
import { simulateAlgorithm, compareAlgorithms } from "./services/api";

export default function App() {
  const [result, setResult] = useState(null);
  const [mode, setMode] = useState(null); // "single" | "compare"
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSimulate = async (inputs) => {
    setLoading(true);
    setError(null);
    try {
      const data = await simulateAlgorithm(inputs);
      setResult(data);
      setMode("single");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCompare = async (inputs) => {
    setLoading(true);
    setError(null);
    try {
      const data = await compareAlgorithms(inputs);
      setResult(data);
      setMode("compare");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-[#000000] text-slate-100 overflow-hidden">
      {/* Dynamic Animated Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Animated Gradient Meshes */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-brand-600/20 blur-[120px] rounded-full mix-blend-screen animate-blob"></div>
        <div className="absolute top-[20%] right-[-10%] w-[50%] h-[50%] bg-blue-600/15 blur-[120px] rounded-full mix-blend-screen animate-blob" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-[-20%] left-[20%] w-[60%] h-[60%] bg-pink-600/15 blur-[120px] rounded-full mix-blend-screen animate-blob" style={{ animationDelay: '4s' }}></div>
        
        {/* Subtle Grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />
      </div>

      <div className="relative z-10">
        <Header />

        <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-[380px_1fr]">
            {/* Left — Configuration */}
            <div className="lg:sticky lg:top-8 lg:self-start">
              <InputPanel
                onSimulate={handleSimulate}
                onCompare={handleCompare}
                loading={loading}
              />
            </div>

            {/* Right — Results */}
            <div className="min-w-0">
              {/* Error */}
              {error && (
                <div className="mb-6 rounded-xl border border-red-500/30 bg-red-500/10 px-5 py-4 text-sm text-red-300 animate-fade-in">
                  <strong>Error:</strong> {error}
                </div>
              )}

              {/* Results or placeholder */}
              {result ? (
                <ResultsPanel data={result} mode={mode} />
              ) : (
                <div className="flex min-h-[400px] items-center justify-center rounded-2xl border border-dashed border-slate-700/50 bg-slate-800/20">
                  <div className="text-center">
                    <span className="mb-3 block text-5xl opacity-30">💿</span>
                    <p className="text-sm text-slate-500">
                      Configure parameters and click <strong className="text-slate-400">Simulate</strong> to begin
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-800/50 py-8 text-center text-xs text-slate-600">
          Advanced Disk Scheduling Simulator &middot; Operating Systems Project
        </footer>
      </div>
    </div>
  );
}
